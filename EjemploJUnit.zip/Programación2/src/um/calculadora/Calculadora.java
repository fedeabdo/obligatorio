package um.calculadora;

public class Calculadora {

	public int sumar(int nA, int nB) {
		int nResultado = nA + nB;

		return nResultado;
	}

}
