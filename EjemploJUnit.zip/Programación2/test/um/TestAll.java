package um;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import um.calculadora.TestCalculadora;
import um.persona.TestPersona;

@RunWith(Suite.class)
@Suite.SuiteClasses({ TestPersona.class, TestCalculadora.class })
public class TestAll {
	// se deja vacia, solamente sirve para colocar las anotaciones
}
