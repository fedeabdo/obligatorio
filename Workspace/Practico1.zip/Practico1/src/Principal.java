import uy.edu.um.prog2.tad.linkedlist.MiListaEncadenada;
public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MiListaEncadenada miLista = new MiListaEncadenada();
		miLista.addLast(10);
		System.out.println(miLista.obtener(0));
//		miLista.agregar(0);
//		miLista.agregar(1);
//		miLista.addFirst(-1);
//		System.out.println(miLista.obtener(0));
//		System.out.println(miLista.obtener(1));
//		miLista.addLast(2);
//		System.out.println(miLista.tamanio());//NO ANDA EL TAMANIO!!!!!
//		System.out.println(miLista.obtener(2));
//		miLista.agregar(2);
//		miLista.agregar(6);
//		System.out.println(miLista.obtener(0));
//		System.out.println(miLista.obtener(1));
//		miLista.eliminar(0);
//		System.out.println(miLista.obtener(0));
//		miLista.addFirst(56);
//		System.out.println();
//		System.out.println(miLista.obtener(0));
//		miLista.addLast(10);
//		System.out.println();
//		System.out.println(miLista.obtener(2));
//		System.out.println();
//		System.out.println(miLista.tamanio());
//		miLista.addFirst(12);
//		System.out.println();
//		System.out.println(miLista.obtener(0));
//		System.out.println(miLista.tamanio());
//		System.out.println();
//		int e = 12;
//		System.out.println("esta " + e + ": " + miLista.esta(e));
	}
	

	
}
