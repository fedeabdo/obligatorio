import uy.edu.um.prog2.tad.linkedlist.MiListaDoblementeEncadenadaCircular;

public class PrincipalDoblementeEncadenadoCircular {

	public static void main(String[] args) {
		MiListaDoblementeEncadenadaCircular miLista = new MiListaDoblementeEncadenadaCircular();
		miLista.agregar(4);
		miLista.agregar(1);
		miLista.addFirst(8);
		miLista.addLast(10);
		System.out.println(miLista.obtener(0) + " " +miLista.obtener(1) + " " +miLista.obtener(2) + " " +miLista.obtener(0));
	}

}
