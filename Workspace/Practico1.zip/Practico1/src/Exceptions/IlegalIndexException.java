package Exceptions;

public class IlegalIndexException extends Exception {

	public IlegalIndexException(String msg) {
		super(msg);
	}

}
