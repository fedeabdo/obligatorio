package Exceptions;

public class IllegalArgumentsException extends Exception{
	public IllegalArgumentsException(String msg) {
		super(msg);
	}

}
