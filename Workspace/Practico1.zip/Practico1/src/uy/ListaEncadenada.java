package uy;

public interface ListaEncadenada {
	void agregar(int i);
	void eliminar(int i);
	int obtener(int i);
	int tamanio();
}
